package com.javabydeveloper.enums;

public enum UserType {
	
	EMPLOYEE, STUDENT;
}
